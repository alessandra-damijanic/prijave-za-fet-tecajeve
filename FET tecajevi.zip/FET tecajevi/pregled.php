<?php
$servername = "localhost";
$username = "id14242940_faks";
$password = "FETfaks@2020";
$dbname = "id14242940_prijave";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, ime, prezime, email, prethodnoobrazovanje, odabirtecaja FROM prijavljeni";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Ime: " . $row["ime"]. "- Prezime: " . $row["prezime"]. " - e-mail: " . $row["email"]. "- Prethodno obrazovanje: " . $row["prethodnoobrazovanje"]. "- Odabrani tečaj: " . $row["odabirtecaja"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>