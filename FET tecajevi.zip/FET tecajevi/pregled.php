<!DOCTYPE html>
<html lang="hr-hr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FET baza tečajeva</title>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    />
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/css/styles.css" />
  </head>
  <body>
    <nav class="navbar navbar-expand-md sticky-top">
      <button
        class="navbar-toggler"
        data-toggle="collapse"
        data-target="#collapsibleNavbar"
      >
        &#9776;
      </button>
      <div
        class="navbar-collapse w-100 jusitfy-content-center"
        id="collapsibleNavbar"
      >
        <ul class="navbar-nav mx-auto">
          <li class="nav-item active">
            <a
              class="nav-link active"
              href="./index.html"
              title="Početna stranica"
              >Naslovnica</a
            >
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              href="./pregled-tecajeva.html"
              title="Pregled svih dostupnih tečajeva"
              >Pregled tečajeva</a
            >
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              href="./prijava-na-tecaj.html"
              title="Prijava na  tečaj"
              >Prijava na tečaj</a
            >
          </li>
          <li class="nav-item">
              <a class="nav-link" href="#" title="Pregled prijava">Pregled prijava</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              href="./kontakt.html"
              title="Kontakt informacije"
              >Kontaktirajte nas</a
            >
          </li>
        </ul>
      </div>
    </nav>
    <div class="header-banner">
            <h1 class="header-text">Pregled prijavljenih osoba na razne tečajeve</h1>
          </div>
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10 offset-md-1">
                <p class="first-desc">
                  U tablici niže možete pogledati tko se sve dosada prijavio na tečaj.
                </p>
    <input class="form-control" id="myInput" type="text" placeholder="Pretraži prijavljene">
  <br>
<table class="table table-striped">                     
    <div class="table responsive">
        <thead>
            <tr>
                <th>Id</th>
              <th>Ime</th>
              <th>Prezime</th>
              <th>e-mail</th>
              <th>Prethodno obrazovanje</th>
               <th>Odabir tečaja</th>
            </tr>
        </thead>
        <tbody id="myTable">

<?php
$servername = "localhost";
$username = "id14242940_faks";
$password = "FETfaks@2020";
$dbname = "id14242940_prijave";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, ime, prezime, email, prethodnoobrazovanje, odabirtecaja FROM prijavljeni";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo '<tr>
                  <td scope="row">' . $row["id"]. '</td>
                  <td>' . $row["ime"] .'</td>
                  <td> '.$row["prezime"] .'</td>
                  <td> '.$row["email"] .'</td>
                  <td> '.$row["prethodnoobrazovanje"] .'</td>
                  <td> '.$row["odabirtecaja"] .'</td>
                </tr>';
  }
} else {
  echo "0 results";
}
$conn->close();
?>
</tbody>
    </div>
</table>
</div>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
</div>
<footer>
          <div class="footer">
            <p>© 2020 Fakultet ekonomije i turizma "Dr. Mijo Mirković", Pula</p>
          </div>
        </footer>
    </div>
  </body>
</html>