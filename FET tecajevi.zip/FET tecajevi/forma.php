<?php
$ime = $_POST ['ime'];
$prezime = $_POST ['prezime'];
$email = $_POST ['email'];
$prethodnoobrazovanje = $_POST ['prethodnoobrazovanje'];
$odabirtecaja = $_POST['odabirtecaja'];
$tecaj="";
foreach($odabirtecaja as $entry){
$tecaj .= $entry.",";
}

$servername = "localhost";
$username = "id14242940_faks";
$password = "FETfaks@2020";
$dbname = "id14242940_prijave";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO prijavljeni (ime, prezime, email, prethodnoobrazovanje, odabirtecaja)
VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sssss', $ime, $prezime, $email, $prethodnoobrazovanje, $tecaj);

if($stmt->execute())

 {
      echo "New user was created successfully, please wait for activation...";
} 
  else { echo "There was a problem";}

  $stmt->close();

$conn->close();
?>