<?php
$ime = $_POST ['ime'];
$prezime = $_POST ['prezime'];
$email = $_POST ['email'];
$prethodnoobrazovanje = $_POST ['prethodnoobrazovanje'];
if($prethodnoobrazovanje)
{
 $chk="";  
    foreach($prethodnoobrazovanje as $p)  
       {  
          mysqli_query($servername, "INSERT INTO  prijavljeni (prethodnoobrazovanje) VALUES ( ' " .mysqli_escape_string($servername,$p)." ')");
       } 
      }
$odabirtecaja = $_POST ['odabirtecaja'];

$servername = "localhost";
$username = "id14242940_faks";
$password = "FETfaks@2020";
$dbname = "id14242940_prijave";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO prijavljeni (ime, prezime, email, prethodnoobrazovanje, odabirtecaja)
VALUES ('$ime', '$prezime','$email','$prethodnoobrazovanje','$odabirtecaja')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>