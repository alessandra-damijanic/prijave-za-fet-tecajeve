function InvalidName(textbox) {
  if (textbox.value === "") {
    textbox.setCustomValidity("Obavezno je upisati ime");
  } else if (textbox.validity.typeMismatch) {
    textbox.setCustomValidity("Molimo Vas da unesete pravilno ime");
  } else {
    textbox.setCustomValidity("");
  }

  return true;
}
function InvalidPrezime(textbox) {
  if (textbox.value === "") {
    textbox.setCustomValidity("Obavezno je upisati prezme");
  } else if (textbox.validity.typeMismatch) {
    textbox.setCustomValidity("Molimo Vas da unesete pravilno prezime");
  } else {
    textbox.setCustomValidity("");
  }

  return true;
}

function InvalidEmail(textbox) {
  if (textbox.value === "") {
    textbox.setCustomValidity("Obavezno je upisati e-mail adresu");
  } else if (textbox.validity.typeMismatch) {
    textbox.setCustomValidity("Molimo Vas da unesete pravilnu e-mail adresu");
  } else {
    textbox.setCustomValidity("");
  }

  return true;
}

$(document).ready(function () {
  $("form").submit(function () {
    if ($("input:checkbox").filter(":checked").length < 1) {
      alert("Molimo Vas da odaberete barem jedan tečaj");
      return false;
    }
  });
});
